





<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">
  <link rel="shortcut icon" href="http://localhost/patient record system/img/rizal.png" />

  <title>Out Patient Findings</title><!-- Ito yung title na dating nasa controller kasama ni $data['title'] n ngayon ginawa natin variable para mailabas sa VIEW yung value ni $title -->

  <!-- Custom fonts for this template-->
  <link rel="stylesheet" type="text/css" href="http://localhost/patient record system/assets/icons/fontawesome-free/css/all.min.css" >
  <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

  <!-- Custom styles for this template-->
  <link rel="stylesheet" type="text/css" href="http://localhost/patient record system/assets/css/sidebar1.css">
   <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>  
 <script src="http://localhost/patient record system/assets/jquery-3.3.1.min.js"></script>

 <link rel="stylesheet" type="text/css" href="http://localhost/patient record system/assets/loader.css">
 
 <script src = "http://localhost/patient record system/assets/js/scripts/bootstrap.js"></script>
<script src = "http://localhost/patient record system/assets/js/scripts/jquery.min.js"></script>
<script src = "http://localhost/patient record system/assets/js/scripts/dropdown.js"></script>
<script src = "http://localhost/patient record system/assets/js/scripts/sidebar.js"></script>
<script src = "http://localhost/patient record system/assets/js/scripts/jquery.dataTables.js"></script>
<script src = "http://localhost/patient record system/assets/js/scripts/custom.js"></script>
<script type = "text/javascript">
	$(document).ready(function() {
		$('#table').DataTable();
		$('#table1').DataTable();
	});
	
</script>

<script src="https://cdn.jsdelivr.net/npm/chart.js@2.8.0"></script>


  <script src = "http://localhost/patient record system/assets/js/scripts/jquery.canvasjs.min.js"></script>


 <style>
   .sidenav {
  width: 100%;
  position: fixed;
  top: 0;
  left: 0;
  background-color: #111;


}


.main {
  margin-left: 225px; /* Same as the width of the sidenav */

}

@media screen and (max-height: 450px) {
  .sidenav {padding-top: 15px;}
  .sidenav a {font-size: 18px;}
}



</style>



</head> 


<body id="page-top">


  <!-- itong part is para malaman kung nakalogin ba si user checheck nya via session  -->
 
 
  <!-- ito naman is para sa validation kung halimbawa magsusubmit na si user ng data lalabas to para sabihin kung naisubmit n ba yung data parang success message, dito sa part na to ang message ay para sa paglogin ng user parang welcome message para sa naglogin na user mga ganun --> 
</div>


          
  </div>
          

  <!-- Page Wrapper -->
  <div id="wrapper">

    <!-- Sidebar -->
    <ul class=" navbar-nav bg-gradient-success sidenav sidebar sidebar-dark accordion " id="accordionSidebar">

      <!-- Sidebar - Brand -->
      <a class="sidebar-brand d-flex align-items-center justify-content-center"  href="#">
        <div class="sidebar-brand-icon rotate-n-0">
           <i class="fas fa-folder-open"></i>
        </div>
        <div class="sidebar-brand-text mx-3">Patient Records</div>
      </a>
   

 <!-- Divider -->
      <hr class="sidebar-divider my-0">

      <!-- Nav Item - Dashboard -->
      <li class="nav-item active">
        <a class="nav-link">
          <i class="fas fa-fw fa-hospital"></i>
          <span>Dashboard</span></a>
      </li>

      <!-- Divider -->
      <hr class="sidebar-divider">


      <!-- Nav Item - for Patient Records Table (link for specific page)-->
      <li class="nav-item active">
         <!-- Nav Item - Tables -->
        <a class="nav-link collapsed " href="http://localhost/patient record system/dashboard.php"> 

          <i class="fas fa-fw fa-table "></i>
          <span>Patient Records Table</span></a>
      </li>

      <!-- Nav Item - for Insert Multiple Record (link for specific page) -->
      <li class="nav-item active">
         <!-- Nav Item - Tables -->
        <a class="nav-link collapsed " href="http://localhost/patient record system/AddRecord.php">
          <i class="fas fa-fw fa-list-alt "></i>
          <span>Add Records</span></a>
      </li>

      <!-- Nav Item - for Add Users (link for specific page)-->
      <li class="nav-item active">
         <!-- Nav Item - Tables -->
        <a class="nav-link collapsed " href="http://localhost/patient record system/AddUser.php">
          <i class="fas fa-fw fa-user-plus "></i>
          <span>Add Users</span></a>
      </li>


      <li class="nav-item active">
         <!-- Nav Item - Tables -->
        <a class="nav-link collapsed " href="http://localhost/patient record system/logscontrol/logsview">
          <i class="fas fa-fw  fa-users "></i>
          <span>User Logs</span></a>
      </li>

      <!-- Divider -->
      <hr class="sidebar-divider d-none d-md-block">


    </ul>
    <!-- End of Sidebar -->

    <!-- Content Wrapper -->
    <div id="content-wrapper" class="main d-flex flex-column">

      <!-- Main Content -->
      <div id="content"> 
 
      
    <!-- Topbar -->
        <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">
 
  
         <!-- Nav Item - Tables -->
        <a  class="nav-link collapsed text-secondary" href="http://localhost/patient record system/multiplerecordcontrol/multiplerecordview">
          <i class="fas fa-fw fa-file "></i>
          <span>Out Patient Findings</span></a>


        <div class="topbar-divider d-none d-sm-block"></div>

         <!-- Nav Item - Tables -->
        <a  class="nav-link collapsed text-secondary" href="http://localhost/patient record system/multiplerecordcontrol/admissionviewform">
          <i class="fas fa-fw fa-bed "></i>
          <span>Admission Record</span></a>


    
          <!-- Topbar Navbar -->
          <ul class="navbar-nav ml-auto">

   
            <div class="topbar-divider d-none d-sm-block"></div>

            <!-- Nav Item - User Information -->
            <li class="nav-item dropdown no-arrow">
              <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <span class="mr-2 d-none d-lg-inline text-gray-600 small">
                  
     <!-- u_user coming from database -->

       <b>admin</b>
                           </span>
              </a>
              <!-- Dropdown - User Information -->
              <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="userDropdown">   
             <a class="dropdown-item" href="http://localhost/patient record system/indexcontrol/changepassupdate">
             <i class="fas fa-fw fa-key mr-2 text-gray-400"></i>
               Change Password
             </a>
             <a class="dropdown-item" href="http://localhost/patient record system/indexcontrol/secretquestion">
             <i class="fas fa-fw fa-user mr-2 text-gray-400"></i>
                Account Recovery
             </a>



                <div class="dropdown-divider"></div>
                <a class="dropdown-item" href="#" data-toggle="modal" data-target="#logoutModal">
                  <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                  Logout
                </a>
              </div>
            </li>

          </ul>

        </nav>
        <!-- End of Topbar -->
 



 <!-- ito n yung variable na kinomvert n na kay $data['topbar'] need mo lagyan ng $this->load->view(); then sa loob yung variable para maiload nya yung nilalaman ni variable $topbar which is yung script para sa navigation bar  --> 
      

        <!-- Begin Page Content -->
        <div class="container-fluid">
       

       

          <!-- DataTales Example -->
          <div id="Findings" class="card shadow mb-4">
      
            <div class="card-header py-3">
           
            <!-- Page Heading -->
          <h5 class="mb-2 text-gray-800"> Out Patient Findings 
                  </h5>  

            </div>
            <div class="card-body">

       <div class="container">
            
             </div>

              <div class="table">
                <table class="table table-bordered " id="dataTable" width="100%" cellspacing="0">
           
                 
                  <tbody>
                   
                <form action="http://localhost/patient record system/multiplerecordcontrol/add_multiple_findings/#Findings" id="add_multiple_findings" class="form-horizontal user" method="post" accept-charset="utf-8">
<div class="container-fluid">

   <div class="row">             
   	 <div class="col-sm-6">
         

               <div style="margin-bottom:17px;">
                <div class="row no-gutters">
                 <div class="text-xs font-weight-bold text-secondary text-uppercase mb-1">Patient Case Number</div>   
                </div>
        <div class="h5 mb-1 font-weight-bold text-gray-800"><input class="form-control " type="text" name="a_casenumber" placeholder="Enter Case Number" value=""> </div>
        <div class="text-danger text-center"></div>
               </div>
   	 
               <div style="margin-bottom:17px;">
               	<div class="row no-gutters">
                 <div class="text-xs font-weight-bold text-secondary text-uppercase mb-1">Chief Complaint</div>   
                </div>
 				<div class="h5 mb-1 font-weight-bold text-gray-800"><textarea class="form-control" type="text" name="a_chief_complaint" placeholder="Enter Chief Complaint"></textarea></div>
               </div>

               <div style="margin-bottom:17px;">
                <div class="row no-gutters">
                 <div class="text-xs font-weight-bold text-secondary text-uppercase mb-1">History of Present Illness</div>   
                </div>
 				<div class="h5 mb-1 font-weight-bold text-gray-800">
          <input class="form-control " type="text" name="a_historyillness" value="" placeholder="Enter History of Present Illness"></div>
        <div class="text-danger text-center"></div>
 			   </div>
    
 			   <div style="margin-bottom:17px;">
 				<div class="row no-gutters">
       <div class="text-xs font-weight-bold text-secondary text-uppercase mb-1">Vital Signs</div>
        </div>
 				  <div class="row"><!--Begin First Column -->
           <div class="col-sm-4">
           <label>Blood Pressure</label>          <input class="form-control" type="text" name="a_bp" value="" placeholder="BP">            
           </div>
           <div class="col-sm-4">
          <label>Respiratory Rate</label>          <input class="form-control" type="text" name="a_rr" value=""  placeholder="RR">  
           </div>
           <div class="col-sm-4">
             <label>Capillary Refill</label>          <input class="form-control" type="text" name="a_cr" value=""  placeholder="CR">   
           </div>
          </div><!--End First Column -->
           <div class="row"><!--Begin Second Column -->
          <div class="col-sm-4">
          <label>Temperature</label>          <input class="form-control" type="text" name="a_temp" value="" placeholder="TEMP">
           </div>
          <div class="col-sm-4">
              <label>Weight</label>          <input class="form-control" type="text" name="a_wt" value="" placeholder="WT">     
           </div>
          <div class="col-sm-4">
              <label>Pulse Rate</label>          <input class="form-control" type="text" name="a_pr" value="" placeholder="PR">  
           </div>

          </div><!--End Second Column -->
 			   </div>

   	 </div><!-- End of Column 1 -->

    <div class="col-sm-6">
       <div style="margin-bottom:17px;">
                <div class="row no-gutters">
                 <div class="text-xs font-weight-bold text-secondary text-uppercase mb-1">Date</div>   
                </div>
        <div class="h5 mb-1 font-weight-bold text-gray-800"><input class="form-control " type="date" name="a_date" placeholder="Enter Case Number" value=""> </div>
        <div class="text-danger text-center"></div>
               </div>

    	       <div style="margin-bottom:17px;">
               	<div class="row no-gutters">
                 <div class="text-xs font-weight-bold text-secondary text-uppercase mb-1">Physical Examination</div>   
                </div>
 				<div class="h5 mb-1 font-weight-bold text-gray-800"><textarea class="form-control" type="text" name="a_physicalexam" placeholder="Enter Physical Examination"></textarea></div>
               </div>

               <div style="margin-top:40px;">
                <div class="row no-gutters">
                 <div class="text-xs font-weight-bold text-secondary text-uppercase mb-1">Diagnosis</div>   
                </div>
 				<div class="h5 mb-1 font-weight-bold text-gray-800"><textarea class="form-control  " type="text" name="a_diagnosis" placeholder="Enter Diagnosis"></textarea></div>
        <div class="text-danger text-center"></div>
 			   </div>
    
 			  <div style="margin-top:40px;">
               	<div class="row no-gutters">
                 <div class="text-xs font-weight-bold text-secondary text-uppercase mb-1">Medication/Treatment</div>   
                </div>
 				<div class="h5 mb-1 font-weight-bold text-gray-800"><textarea class="form-control  " type="text" name="a_medical_treatment" placeholder="Enter Medication/Treatment"></textarea></div>
        <div class="text-danger text-center"></div>
               	</div>

 			   </div><!-- End of Column 2 -->
    </div><!-- End of Row -->
    <div class="row">
      <div class="col-sm-6">
           <div style="margin-bottom:17px;">
                <div class="row no-gutters">
                 <div class="text-xs font-weight-bold text-secondary text-uppercase mb-1"> Attending Physician</div>   
                </div>
           <select name="a_physician" class="form-control">
              <option value="">Select Physician</option>
                                                      <option value=Marilyn.Madrid / Pediatrician>Dr. Marilyn.Madrid / Pediatrician</option>
                                           <option value=Noa.Santiago / Dermatologist>Dr. Noa.Santiago / Dermatologist</option>
                                           <option value=James.Santos / Ophthalmologist>Dr. James.Santos / Ophthalmologist</option>
                                           <option value=John.Gomez / Orthopedic.surgeon>Dr. John.Gomez / Orthopedic.surgeon</option>
                                           <option value=Jobelle.Castro / Psychiatrist>Dr. Jobelle.Castro / Psychiatrist</option>
                                           <option value=Maria.Cruz / Gynecologist>Dr. Maria.Cruz / Gynecologist</option>
                                           <option value=Gabriel.Lopez / Surgeon>Dr. Gabriel.Lopez / Surgeon</option>
                                           <option value=Juan.Monton / Emergency.Medicine.Specialist>Dr. Juan.Monton / Emergency.Medicine.Specialist</option>
                                                                </select> 
                <div class="text-danger text-center"></div>  
              </div>
         </div>
      <div class="col-sm-6">
        
           </div>
            </div>

           <button style='margin-left: 410px; margin-bottom: 20px; text-decoration:none' type='submit' class='btn btn-success btn-icon-split' name='submit' href='http://localhost/patient record system/multiplerecordcontrol/add_multiple_findings'> 
                 <span class="icon text-white-100">
                  <i class="fas fa-arrow-right"></i>  
                    Add Findings
                  </span>
                </button>	

</div>
 
  
  </form>

<script>
  $(document).ready(function(){

   $('#medicalfield').change(function(){
  var fp_id = $('#medicalfield').val();
  if (fp_id != '')
  {
   $.ajax({
    url:"http://localhost/patient record system/admissioncontrol/get_physician",
    method:"POST",
    data:{fp_id:fp_id},
    success:function(data)
    {
     $('#physician').html(data);
    }
   });
  }
  else
  {
   $('#physician').html('<option value="">Select Physician</option>');
  }
 });

});
</script>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
 <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>		
                  </tbody>

                </table>
              </div>
            </div>
          </div>

 <!-- ganun din dito ito naman scripts para sa isang bahagi ng website -->
            
        </div>
       
       </div>
      <!-- End of Main Content -->
  <br><br><br><br><br><br><br><br><br><br>
      <!-- Footer -->
      <footer class="sticky-footer bg-white">
        <div class="container my-auto">
          <div class="copyright text-center my-auto">
            <span>Copyright &copy; FOTIO WILFRIED PATIENTS RECORD SYSTEM ICTU</span>
          </div>
        </div>
      </footer>
      <!-- End of Footer -->

    </div>
    <!-- End of Content Wrapper -->

  </div>
  <!-- End of Page Wrapper -->

  <!-- Scroll to Top Button-->
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>

  <!-- Logout Modal-->
  <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
          <button class="close" type="button" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">×</span>
          </button>
        </div>
        <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
        <div class="modal-footer">
          <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
          <a class="btn btn-success" href="http://localhost/patient record system/usercontrol/logout">Logout</a>
        </div>
      </div>
    </div>
  </div>

 


 <!-- Bootstrap core JavaScript-->
  <script src="http://localhost/patient record system/assets/third party plugins/jquery/jquery.min.js"></script>
  <script src="http://localhost/patient record system/assets/third party plugins/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Core plugin JavaScript-->
  <script src="http://localhost/patient record system/assets/third party plugins/jquery-easing/jquery.easing.min.js"></script>

  <!-- Custom scripts for all pages-->
  <script src="http://localhost/patient record system/assets/js/sb-admin-2.min.js"></script>

  <!-- Page level plugins -->
  <script src="http://localhost/patient record system/assets/third party plugins/datatables/jquery.dataTables.min.js"></script>
  <script src="http://localhost/patient record system/assets/third party plugins/datatables/dataTables.bootstrap4.min.js"></script>

  <!-- Page level custom scripts -->
  <script src="http://localhost/patient record system/assets/js/demo/datatables-demo.js"></script>

  
<!-- jQuery library -->
<script src="http://localhost/patient record system/assets/printarea/jquery-print-plugin-master/lib/jquery.printThis.js"></script>
 


</body>

</html>


