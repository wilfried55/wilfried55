<?php

function Createdatabase(){
    $servername ="localhost";
    $username ="root";
    $password ="";
    $databasename = "PATIENTSRECORD";
//established connection
    $con = mysql_connect($servername,$username,$password,$databasename);
//check connection
    if(!$con){
        die("Connection Failure:".mysql_connect_error());
    }
    //create database
      $sql = "create databse if not exit $databasename";
      
      if(mysql_query($con,$sql)){

       
          echo "Database Created..!";
        
      }else{
          echo "Error while creating database ".mysql_error($con);
      }
}