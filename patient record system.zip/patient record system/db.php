<?php

function Createdb(){
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname ="patientsrecord";

    $con = mysqli_connect($servername, $username, $password);

     $sql = "CREATE DATABASE IF NOT EXISTS $dbname";

    if(mysqli_query($con, $sql)){
        $con = mysqli_connect($servername, $username, $password,$dbname);
          $sql="
                 CREATE TABLE IF NOT EXIS patientinfor(
                     id INT(12) NOT NULL AUTO_INCREMENT PRIMARY KEY,
                     pt_user_id INT(20),
                     pt_date DATE(),
                     lname VARCHAR(20),
                     fname VARCHAR(20),
                     address VARCHAR(20),
                     age INT(11),
                     birthdate DATE(),
                     birthplace VARCHAR(20),
                     civilstatut VARCHAR(20),
                     gender VARCHAR(20),
                     phnumber VARCHAR(20),
                     religion VARCHAR(20),
                     occupation VARCHAR(20),
                     month VARCHAR(20),
                     year VARCHAR(20),

                 );
          ";
           
          if(mysqli_query($con, $sql)){
              return $con;
          }else{
              echo "cannot create table";
          }
   
    }else{
        echo "Error while creating data".mysqli_error($con);
    }
}