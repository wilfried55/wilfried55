<?php

require_once("db.php");

$con = Createdb();

if(isset($_POST['submit'])){
    echo "Creat buttom clicked";
}